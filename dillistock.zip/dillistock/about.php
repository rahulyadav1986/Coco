<?php
/*
Template Name: About Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <div class="inner_hero_back d-flex align-items-center justify-content-center">
        <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-hero-banner',true);?>" alt="">
        <div class="container">
            <h1><?php the_title();?></h1>
            <ul class="bedcrumb d-flex justify-content-center">
                <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
                <li><?php the_title();?></li>
            </ul>
        </div>
    </div>

    <div class="about_us_back inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="portion e_left">
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-about-custom-heading',true);?></h2>
                        <?php the_content();?>                        
                    </div>

                </div>

            </div>
        </div>
    </div>

    
    
  

<?php endwhile; ?>   
<?php

get_footer();
?>