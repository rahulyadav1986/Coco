<div class="what_we_best_back">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 order-lg-3">
                    <div class="portion last">
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-why-best-heading',true);?></h2>
                        <p><?php echo get_post_meta(get_the_ID(),'wpcf-why-best-content',true);?></p>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="portion">
                        <?php echo get_post_meta(get_the_ID(),'wpcf-why-best-list-one',true);?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="portion">
                        <?php echo get_post_meta(get_the_ID(),'wpcf-why-best-list-two',true);?>
                    </div>
                </div>

            </div>
        </div>
    </div>