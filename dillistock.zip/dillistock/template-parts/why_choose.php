<section class="custom-why-choose custom-pad">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-12">
				<div class="custom-heading">
						<span><?php echo get_post_meta(get_the_ID(),'wpcf-home-service-sub-heading',true);?></span>
						<h3><?php echo get_post_meta(get_the_ID(),'wpcf-home-service-heading',true);?></h3>
					</div>
			</div>
			<div class="col-lg-6 col-md-12">
				<div class="why-choose-content">
					<p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-home-service-content',true);?></p>
				</div>
			</div>
		</div>
		<div class="row">
		<?php $query_args = array(
                'post_type' => 'services',
                'posts_per_page' => '4' ,
                'order' => 'DESC'
                );
                $query = new WP_Query( $query_args ); ?>
        
                <?php if ( $query->have_posts() ) : ?>
                    <?php while ( $query->have_posts() ) : $query->the_post(); get_template_part( 'template-parts/content/service-content' ); ?>
                    <?php endwhile; ?>
                <?php endif; ?>

        <?php wp_reset_postdata(); ?>
		</div>
		<div class="row">
			<div class="why-chhose-btm-conent">
				<p class="demo">Stop wasting time and money on Cleaning. <a href="#">Make An Appointment</a></p>
			</div>
		</div>
	</div>
</section>