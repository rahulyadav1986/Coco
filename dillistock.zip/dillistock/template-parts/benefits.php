<section class="benifit">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 common">
				<div class="about-heading">
					<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-benefits-sub-heading',true);?> ]</h6>
					<h2><?php echo get_post_meta(get_the_ID(),'wpcf-benefits-heading',true);?></h2>
				</div>
				<a href="#" class="custom-btn">LEARN MORE</a>
			</div>
			<div class="col-lg-8 common">
				<div class="right_details">
					<div class="row">
                    <?php
                        $args = array(
                            'numberposts' => -1,
                            'offset' => 0,
                            'orderby' => 'post_date',
                            'order' => 'ASC',
                            'include' => '',
                            'exclude' => '',
                            'meta_key' => '',
                            'meta_value' => '',
                            'post_type' => 'benefit',
                            'post_status' => 'draft, publish, future, pending, private',
                            'suppress_filters' => true
                            );
                            $j = 1;
                            $benefit = wp_get_recent_posts( $args, ARRAY_A );
                            foreach ( $benefit as $benefit ) {
                            $title = ($benefit['post_title']);
                            $content = ($benefit['post_content']);
                            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $benefit[ 'ID' ] ), 'single-post-thumbnail' );
                        
                        ?>
						<div class="col-md-6">
							<div class="portion">
								<img src="<?php echo $image[0]; ?>" alt="">
								<h3><?php echo $title; ?></h3>
								<p><?php echo $content; ?></p>
							</div>
						</div>
                        <?php $j++;} ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>