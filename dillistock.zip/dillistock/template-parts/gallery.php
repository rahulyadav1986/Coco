<section class="our_gallery_back" id="galleries">
	<div class="container">
		<div class="about-heading text-center">
			<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-gallery-sub-heading',true);?> ]</h6>
			<h2><?php echo get_post_meta(get_the_ID(),'wpcf-gallery-heading',true);?></h2>
		</div>
		<div class="main_gallery">
			<div class="row">
			<?php $ix_result = get_post_meta(get_the_ID(),'wpcf-home-gallery',true);
		   
					$part_1 = str_replace('[gallery ids="',"",$ix_result);
					$part_2 = str_replace('"]',"",$part_1);
					
					//print_r($part_2);
					
					$gallery_ids = explode(',', $part_2);
						foreach ($gallery_ids as $gallery_id)
						{
						
						$feat_image_url = wp_get_attachment_url( $gallery_id );
					
					?>
					<div class="col-md-4">
						<div class="portion">
							<a href="<?php echo $feat_image_url ?>" data-fancybox="gallery" data-caption="">
								<img src="<?php echo $feat_image_url ?>" alt="">
							</a>
						</div>
					</div>
				<?php } ?>
				
				
				
				
			</div>
		</div>
		<a href="<?php echo get_post_meta(get_the_ID(),'wpcf-gallery-button-url',true);?>" class="custom-btn"><?php echo get_post_meta(get_the_ID(),'wpcf-gallery-button-text',true);?></a>
	</div>
</section>
