<div class="amazing_contributor_back" >
       <div class="container">
            <?php dynamic_sidebar('logo') ?>
            <div class="heading text-center">                
                <span></span>
                <h2><?php echo get_post_meta(get_the_ID(),'wpcf-contributor-heading',true);?></h2>
            </div>
            <div class="mainslider_back owl-carousel owl-theme" id="client-carousel">
            <?php
                $args = array(
                    'numberposts' => -1,
                    'offset' => 0,
                    'orderby' => 'post_date',
                    'order' => 'ASC',
                    'include' => '',
                    'exclude' => '',
                    'meta_key' => '',
                    'meta_value' => '',
                    'post_type' => 'contributor',
                    'post_status' => 'draft, publish, future, pending, private',
                    'suppress_filters' => true
                    );
                    $j = 1;
                    $gallery = wp_get_recent_posts( $args, ARRAY_A );
                    foreach ( $gallery as $gallery ) {
                    $title = ($gallery['post_title']);
                    $excerpt = ($gallery['post_excerpt']);
                    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery[ 'ID' ] ), 'single-post-thumbnail' );
                
                ?> 
                <div class="portion">
                    <img src="<?php echo $image[0] ?>" alt="">
                    <h4><?php echo $title ?></h4>
                    <p><?php echo $excerpt ?></p>
                </div>
                <?php $j++;} ?>
                
            </div>
            <div class="clear"></div>
            <div class="custom_button"><a href="<?php echo get_post_meta(get_the_ID(),'wpcf-contributor-button-url',true);?>"><?php echo get_post_meta(get_the_ID(),'wpcf-contributor-button-text',true);?></a></div>
       </div>
   </div>

   <div class="join_us_back">
       <div class="container">
           <p><?php echo get_post_meta(get_the_ID(),'wpcf-tagline-heading',true);?></p>
           <div class="custom_button"><a href="tagline-button-url"><?php echo get_post_meta(get_the_ID(),'wpcf-tagline-button-text',true);?></a></div>
       </div>
   </div>
   
   

   