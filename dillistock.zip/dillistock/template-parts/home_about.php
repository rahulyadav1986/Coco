<div class="home_about_us_back">
       <div class="container">
           <div class="row">
            <div class="col-lg-4 order-lg-2">
                <div class="image_back">
                    <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-about-image',true);?>" alt="">
                </div>
            </div>
               <div class="col-lg-8">
                   <div class="left_content">
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-about-heading',true);?></h2>
                        <p><?php echo get_post_meta(get_the_ID(),'wpcf-about-drescription',true);?></p>                        
                        <?php echo get_post_meta(get_the_ID(),'wpcf-about-button-details',true);?>
                   </div>                   
               </div>
               
           </div>
       </div>
   </div>
