<div class="hero_back">
       <div class="ovarlay"></div>
       <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-banner-image',true);?>" alt="">
       <div class="container">
           <h1><?php echo get_post_meta(get_the_ID(),'wpcf-banner-heading',true);?></h1>
           <p><?php echo get_post_meta(get_the_ID(),'wpcf-banner-drescription',true);?></p>
           <div class="search_box">
               <input type="text" placeholder="Search images...">
               <div class="submit_button">
                   <input type="submit" value="Search">
               </div>
           </div>
       </div>
   </div>
   <div class="bottom_sign_up_back">
       <div class="container"><?php echo get_post_meta(get_the_ID(),'wpcf-signup-text',true);?></div>
   </div>

   