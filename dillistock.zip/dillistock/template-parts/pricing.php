<section class="our_pricing_back">
	<div class="container">
		<div class="about-heading text-center">
			<h6>[ <?php echo get_post_meta(get_the_ID(),'wpcf-pricing-sub-heading',true);?> ]</h6>
			<h2><?php echo get_post_meta(get_the_ID(),'wpcf-pricing-heading',true);?></h2>
		</div>
		<div class="mian_pricing_back">
			<div class="row">
			<?php
				$args = array(
					'numberposts' => -1,
					'offset' => 0,
					'orderby' => 'post_date',
					'order' => 'ASC',
					'include' => '',
					'exclude' => '',
					'meta_key' => '',
					'meta_value' => '',
					'post_type' => 'pricing',
					'post_status' => 'draft, publish, future, pending, private',
					'suppress_filters' => true
					);
					$j = 1;
					$pricing = wp_get_recent_posts( $args, ARRAY_A );
					foreach ( $pricing as $pricing ) {
					$title = ($pricing['post_title']);
					$excerpt = ($pricing['post_excerpt']);
				
				?>
				<div class="col-md-4 port">
					<div class="back">
						<div class="portion">
							<div class="plan_title"><?php echo $title ?></div>
							<div class="price">
								<h3><?php echo get_post_meta($pricing['ID'],'wpcf-price',true);?></h3>
								<h4>Special Pricing</h4>
							</div>
							<div class="title"><?php echo get_post_meta($pricing['ID'],'wpcf-treatment-type',true);?></div>
							<div class="sub_title"><?php echo $excerpt ?></div>
						</div>
					</div>
					
				</div>
				<?php $j++;} ?>
			</div>
		</div>
		
	</div>
</section>

