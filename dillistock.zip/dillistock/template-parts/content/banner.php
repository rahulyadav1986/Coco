<div class="banner_back">
        <img class="flag" src="<?php echo get_template_directory_uri(); ?>/images/flag.png" alt="">
        <img class="curve" src="<?php echo get_template_directory_uri(); ?>/images/sli_curve.png" alt="">
        <div class="slider_back">
            <div class="container">
                

                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ul class="carousel-indicators">
                      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                      <li data-target="#myCarousel" data-slide-to="1"></li>
                      <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ul>
                    
                    <!-- The slideshow -->
                    <div class="carousel-inner">
                      <?php
					  $args = array(
                        'numberposts' => -1,
                        'offset' => 0,
                        'orderby' => 'post_date',
                        'order' => 'ASC',
                        'include' => '',
                        'exclude' => '',
                        'meta_key' => '',
                        'meta_value' => '',
                        'post_type' => 'banner',
                        'post_status' => 'draft, publish, future, pending, private',
                        'suppress_filters' => true
                        );
                        $j = 1;
                        $banner = wp_get_recent_posts( $args, ARRAY_A );
                        foreach ( $banner as $banner ) {
                        $content = ($banner['post_content']);
                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $banner[ 'ID' ] ), 'single-post-thumbnail' );
				  
				        ?>
                        <div class="carousel-item <?php if($j==1) {?>active <?php }?>">
                            <div class="content_back">                                
                                <?php echo $content; ?>
                            </div>
                            <img src="<?php echo $image[0]; ?>" alt="">
                        </div>

                        <?php $j++;} ?>

                    </div>
                  </div>

            </div>
        </div>
        
    </div>
