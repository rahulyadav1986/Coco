<div class="browse_category">
       <div class="container">
           <div class="heading text-center">
               <span></span>
               <h2><?php echo get_post_meta(get_the_ID(),'wpcf-browse-category-heading',true);?></h2>
               <p><?php echo get_post_meta(get_the_ID(),'wpcf-browse-category-drescription',true);?></p>
           </div>
           <div class="main_gallery_back">
            <?php
                $args = array(
                    'numberposts' => -1,
                    'offset' => 0,
                    'orderby' => 'post_date',
                    'order' => 'ASC',
                    'include' => '',
                    'exclude' => '',
                    'meta_key' => '',
                    'meta_value' => '',
                    'post_type' => 'gallery',
                    'post_status' => 'draft, publish, future, pending, private',
                    'suppress_filters' => true
                    );
                    $j = 1;
                    $gallery = wp_get_recent_posts( $args, ARRAY_A );
                    foreach ( $gallery as $gallery ) {
                    $title = ($gallery['post_title']);
                    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery[ 'ID' ] ), 'single-post-thumbnail' );
                
                ?> 
               <a href="<?php echo $image[0] ?>"  data-fancybox="gallery" data-caption="<?php echo $title ?>" class="portion">
                   <p><?php echo $title ?></p>
                   <img src="<?php echo $image[0] ?>" alt="">
               </a>
               <?php $j++;} ?>
           </div>
       </div>
   </div>