
<div class="before_after_back d-flex align-items-center">
        <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-image',true);?>" alt="">
        <div class="container">
            <div class="details">
                <h2><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-images-heading',true);?></h2>
                <p><?php echo get_post_meta(get_the_ID(),'wpcf-before-after-content',true);?></p>
                <div>
                <div>
                    <div class="custom_button">
                        <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-one-url',true);?>">
                            <span></span>
                            <?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-one-text',true);?>
                            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-one-icon',true);?>" alt="">
                        </a>
                    </div>
                    <div class="custom_button">
                        <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-two-url',true);?>">
                            <span></span>
                            <?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-two',true);?>
                            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-before-after-button-two-icon',true);?>" alt="">
                        </a>
                    </div>
                </div>
                </div>

            </div>

        </div>
</div>
<?php require_once('before_after_section.php') ?>
