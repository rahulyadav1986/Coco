<?php
/*
Template Name: Contact Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <div class="inner_hero_back d-flex align-items-center justify-content-center">
        <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-hero-banner',true);?>" alt="">
        <div class="container">
            <h1><?php the_title();?></h1>
            <ul class="bedcrumb d-flex justify-content-center">
                <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
                <li><?php the_title();?></li>
            </ul>
        </div>
    </div>

    <div class="get_touch_back contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <h2>Contact Info</h2>
                    <div class="contact_details">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="portion">
                                    <div class="image_back">
                                        <img src="<?php echo get_template_directory_uri(); ?>/images/con1.png" alt="">
                                    </div>
                                    <h3>Visit Us Daily:</h3>
                                    <p><?php echo get_post_meta(get_the_ID(),'wpcf-office-address',true);?></p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="portion">
                                    <div class="image_back">
                                        <img src="<?php echo get_template_directory_uri(); ?>/images/con2.png" alt="">
                                    </div>
                                    <h3>Phone Us :</h3>
                                    <p><?php echo get_post_meta(get_the_ID(),'wpcf-office-phone',true);?></p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="portion">
                                    <div class="image_back">
                                        <img src="<?php echo get_template_directory_uri(); ?>/images/con3.png" alt="">
                                    </div>
                                    <h3>Mail Us  :</h3>
                                    <p><?php echo get_post_meta(get_the_ID(),'wpcf-office-mail',true);?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <h2>Get Quote</h2>
                    <?php echo do_shortcode('[contact-form-7 id="65" title="Contact Us Form"]') ?>
                </div>
            </div>

        </div>
        <div class="map">
            <iframe src="<?php echo get_post_meta(get_the_ID(),'wpcf-office-map',true);?>" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
    </div>


    
    
  

<?php endwhile; ?>   
<?php

get_footer();
?>