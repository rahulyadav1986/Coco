<?php
/*
Template Name: Welcome Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <?php require_once('template-parts/banner.php') ?>
  <?php require_once('template-parts/home_about.php') ?>
  <?php require_once('template-parts/brows_category.php') ?>
  <?php require_once('template-parts/contributor.php') ?>

<?php endwhile; ?>   
<?php

get_footer();
?>