<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>

<footer class="custom-footer">
	<div class="footer-top">
		<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6">
				<div class="footer-col footer-col-1">
					<?php dynamic_sidebar('f_about') ?>
				</div>
			</div>
			<div class="col-lg-2 col-md-6">
				<div class="footer-col footer-col-2">
					<h5>Services</h5>
					<?php
						wp_nav_menu( array(
						'theme_location'    => 'services',
						'container'  => '',
						'depth'             => 2,
						'items_wrap' => '<ul>%3$s</ul>' ,
						'menu_class'        => '',
						
						) );
					?>
					
				</div>
			</div>
			<div class="col-lg-2 col-md-6">
				<div class="footer-col footer-col-3">
					<h5>Quick Links</h5>
					<?php
						wp_nav_menu( array(
						'theme_location'    => 'footer_menu',
						'container'  => '',
						'depth'             => 2,
						'items_wrap' => '<ul>%3$s</ul>' ,
						'menu_class'        => '',
						
						) );
					?>
				</div>
			</div>
			<div class="col-lg-5 col-md-6">
				<div class="footer-col footer-col-4">
					<?php dynamic_sidebar('f_contact') ?>
					<div class="row">
						<div class="col-lg-6">
							<div class="footer-con-dp">
								<ul>
									<li><a href="#"> <?php dynamic_sidebar('f_phone') ?></a></li>
									<li><a href="#"> <?php dynamic_sidebar('f_email') ?></a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="footer-social">
								<ul>
									<?php dynamic_sidebar('social') ?>
								</ul>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="footer-btm">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<?php dynamic_sidebar('copyright') ?>
				</div>
			</div>
		</div>
	</div>
	
</footer>

<!-- Optional JavaScript --> 
<!-- jQuery first, then Popper.js, then Bootstrap JS --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-migrate-1.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>

<?php wp_footer(); ?>

</body>
</html>
