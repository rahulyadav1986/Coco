<section class="custom-pricing custom-pad">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="custom-heading">
						<span>Pricing</span>
						<h3>Price Packages</h3>
					</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="custom-pricing-wrap">
					<ul class="detils">
					<?php
						$args = array(
							'numberposts' => -1,
							'offset' => 0,
							'orderby' => 'post_date',
							'order' => 'ASC',
							'include' => '',
							'exclude' => '',
							'meta_key' => '',
							'meta_value' => '',
							'post_type' => 'pricingtable',
							'post_status' => 'draft, publish, future, pending, private',
							'suppress_filters' => true
							);
							$j = 1;
							$pricingtable = wp_get_recent_posts( $args, ARRAY_A );
							foreach ( $pricingtable as $pricingtable ) {
							$title = ($pricingtable['post_title']);
						
						?>
						<li>
							<div class="portion">
								<div class="head">
									<img src="<?php echo get_post_meta($pricingtable['ID'],'wpcf-table-table-icon',true);?>" alt="">
									<h3><?php echo get_post_meta($pricingtable['ID'],'wpcf-table-sub-title',true);?></h3>
									<h2><?php echo $title ?></h2>
								</div>
								<div class="body_details">									
									<?php echo get_post_meta($pricingtable['ID'],'wpcf-table-details',true);?>
								</div>
								<div class="footer_details">
									<div class="price"> <?php echo get_post_meta($pricingtable['ID'],'wpcf-table-price',true);?></div>
									<a href="<?php echo get_post_meta($pricingtable['ID'],'wpcf-button-link',true);?>" class="pricing_button">Order Now</a>
								</div>
							</div>
						</li>
						<?php $j++;} ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>