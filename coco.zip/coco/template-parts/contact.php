<section class="custom-contact custom-pad" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/contact-bg.jpg);">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="custom-heading">
						<span>Make Appointment</span>
						<h3>Make An Appointment</h3>
					</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="custom-contact-frm">
					<?php echo do_shortcode('[contact-form-7 id="5" title="Home Contact Form"]') ?>
				</div>
			</div>
		</div>
	</div>
</section>