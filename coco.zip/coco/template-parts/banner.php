<section class="custom-banner">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
    <?php
      $args = array(
        'numberposts' => -1,
        'offset' => 0,
        'orderby' => 'post_date',
        'order' => 'ASC',
        'include' => '',
        'exclude' => '',
        'meta_key' => '',
        'meta_value' => '',
        'post_type' => 'banner',
        'post_status' => 'draft, publish, future, pending, private',
        'suppress_filters' => true
        );
        $j = 1;
        $banner = wp_get_recent_posts( $args, ARRAY_A );
        foreach ( $banner as $banner ) {
        $title = ($banner['post_title']);
        $content = ($banner['post_content']);
        $excerpt = ($banner['post_excerpt']);
        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $banner[ 'ID' ] ), 'single-post-thumbnail' );
    
          ?>
      <div class="carousel-item <?php if($j==1) {?>active <?php }?>"> 
      <img class="d-block w-100" src="<?php echo $image[0]; ?>" alt="First slide">
        <div class="carousel-caption dp-caption">
          <div class="container">
            <div class="row">
              <div class="col-lg-11 offset-lg-1 col-md-12">
                <h6><?php echo $title; ?></h6>
                <h2><?php echo $excerpt; ?></h2>
                <?php echo $content; ?>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php $j++;} ?>
      
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev"> <i class="fas fa-arrow-left"></i> </a> <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next"> <i class="fas fa-arrow-right"></i> </a> </div>
  <div class="banner-call">
    <div class="container-fluid">
      <div class="col-md-12">
        <div class="banner-call-wrap">
          <div class="media">
          
            <div class="media-body">
              <h6 class="mt-0 mb-1">Get Free Estimate</h6>
              <a href="tel:123-456-7890">+123-456-7890</a> 
              </div>
            <img class="ml-3" src="<?php echo get_template_directory_uri(); ?>/images/call-icon.png" alt="Generic placeholder image"> 
            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

