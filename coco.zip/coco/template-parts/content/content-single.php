<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>




<div class="why-choose-wrap">
	<div class="row">
		<div class="col-md-3">
			<div class="why-choose-img">
				<a href="<?php the_permalink(); ?>"><?php twentynineteen_post_thumbnail(); ?></a>
			</div>
		</div>
		<div class="col-md-9">
			<div class="why-choose-inner-content">
				<div class="choose-icon">
					<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-service-icon',true);?>" alt="">
				</div>
				<div class="why-choose-heading">
					<h6><?php echo get_post_meta(get_the_ID(),'wpcf-service-sub-heading',true);?></h6>
					<h4><?php the_title(); ?></h4>
					<p class="demo"><?php the_content(); ?></p>
				</div>
			</div>
		</div>
	</div>
	
	
</div>
