<div class="abt-tes">
    <div id="tes-owl" class="owl-carousel owl-theme">
        <?php
            $args = array(
            'numberposts' => -1,
            'offset' => 0,
            'orderby' => 'post_date',
            'order' => 'ASC',
            'include' => '',
            'exclude' => '',
            'meta_key' => '',
            'meta_value' => '',
            'post_type' => 'testimonial',
            'post_status' => 'draft, publish, future, pending, private',
            'suppress_filters' => true
            );
            $j = 1;
            $testimonial = wp_get_recent_posts( $args, ARRAY_A );
            foreach ( $testimonial as $testimonial ) {
            $content = ($testimonial['post_content']);
            $excerpt = ($testimonial['post_excerpt']);
            $title = ($testimonial['post_title']);

        ?>
            <div class="item">
                <p class="demo"><?php echo $content ?></p>
                <h5><?php echo $title ?>, <span><?php echo $excerpt ?></span></h5>
            </div>
        <?php $j++;} ?>
    </div>
</div>