<section class="custom-about custom-pad">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-12">
				<div class="about-us-img">
					<div class="abt-img-1">
						<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-image-1-home-page',true);?>" alt="">
					</div>
					<div class="about-img-2">
						<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-image-2-home-page',true);?>" alt="">
					</div>
					<div class="about-img-3">
						<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-image-3-home-page',true);?>" alt="">
					</div>
					<div class="dp-exp">						
						<?php echo get_post_meta(get_the_ID(),'wpcf-year-experience',true);?>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12">
				<div class="about-us-content">
					<div class="custom-heading">
						<span><?php echo get_post_meta(get_the_ID(),'wpcf-sub-heading',true);?></span>
						<h3><?php echo get_post_meta(get_the_ID(),'wpcf-main-heading-home-page',true);?></h3>
					</div>
					<p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-content-home-page',true);?></p>
					<?php echo get_post_meta(get_the_ID(),'wpcf-featured-heading-home-page',true);?>
					<?php require_once('testimonials.php')?>
				</div>
			</div>
		</div>
	</div>
</section>