<?php
/*
Template Name: About Us Template
*/
get_header();
?>
<?php
    while ( have_posts() ) :
    the_post();
?>

<section class="inner-banner" style="background-image: url('<?php echo get_post_meta(get_the_ID(),'wpcf-main-bg',true);?>');">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h2><?php the_title();?></h2>
					<ul class="custom-breadcam">
						<li><a href="#">Home</a></li>
						<li>About Us</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="inner-about custom-pad">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-12 align-self-center">
				<div class="abt-inr-img">
                    <?php twentynineteen_post_thumbnail(); ?>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 align-self-center">
				<div class="abt-inr-content">
					<div class="custom-heading">
						<span><?php echo get_post_meta(get_the_ID(),'wpcf-about-sub-heading',true);?></span>
						<h3><?php echo get_post_meta(get_the_ID(),'wpcf-about-heading',true);?></h3>
                    </div>
                    <?php the_content(); ?>					
				</div>
			</div>
		</div>
	</div>
</section>

<?php endwhile; ?>     
<?php
get_footer();
?>