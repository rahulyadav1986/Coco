<?php
/*
Template Name: Contact Us Template
*/
get_header();
?>
<?php
    while ( have_posts() ) :
    the_post();
?>

<section class="inner-banner" style="background-image: url('<?php echo get_post_meta(get_the_ID(),'wpcf-main-bg',true);?>');">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h2><?php the_title();?></h2>
					<ul class="custom-breadcam">
						<li><a href="#">Home</a></li>
						<li>About Us</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="inner-about contact custom-pad">
	<div class="container-fluid">
		<div class="row">
            <div class="col-md-4">
                <div class="map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3560.1332664108286!2d152.96092431565512!3d-26.835713296462135!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b9384b3394378fb%3A0x912d04a1146aed33!2sAustralia%20Zoo!5e0!3m2!1sen!2sin!4v1609337193039!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
            <div class="col-md-4">
                <div class="custom-contact-frm">
					<?php echo do_shortcode('[contact-form-7 id="72" title="Contact us Page Form"]') ?>
				</div>
            </div>
            <div class="col-md-4">
                <h2>Request A Call Back</h2>
                <p>Lorem Ipsum has been the industry's standard dummy text</p>
                <ul class="contact-details">
                    <li>
                        <img src="http://localhost/coco-cleaning/wp-content/uploads/2020/12/hi1.png" alt="" class="icon">
                        <p>There are many variations of passages</p>
                    </li>
                    <li>
                        <img src="http://localhost/coco-cleaning/wp-content/uploads/2020/12/hi2.png" alt="" class="icon">
                        <p>1300 856 603</p>				
                    </li>
                    <li>
                        <img src="http://localhost/coco-cleaning/wp-content/uploads/2020/12/hi3.png" alt="" class="icon">
                        <p>info-demo@demomail.com.au</p>				
                    </li>
                </ul>
            </div>
        </div>
	</div>
</section>

<?php endwhile; ?>     
<?php
get_footer();
?>