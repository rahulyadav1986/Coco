// JavaScript Document
jQuery('#tes-owl').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});


(function ($) {	

	jQuery.fn.searchBox = function(ev) {

		var $searchEl = jQuery('.search-elem');
		var $placeHolder = jQuery('.placeholder');
		var $sField = jQuery('#search-field');

		if ( ev === "open") {
			$searchEl.addClass('search-open')
		};

		if ( ev === 'close') {
			$searchEl.removeClass('search-open'),
			$placeHolder.removeClass('move-up'),
			$sField.val(''); 
		};

		var moveText = function($) {
			$placeHolder.addClass('move-up');
		}

		$sField.focus(moveText);
		$placeHolder.on('click', moveText);
		
		jQuery('.submit').prop('disabled', true);
		jQuery('#search-field').keyup(function() {
	        if(jQuery(this).val() != '') {
	           jQuery('.submit').prop('disabled', false);
	        }
	    });
	}	

}(jQuery));

jQuery('.search-btn').on('click', function(e) {
	jQuery(this).searchBox('open');
	e.preventDefault();
});

jQuery('.close').on('click', function() {
	jQuery(this).searchBox('close');
});
jQuery('[data-fancybox="gallery"]').fancybox({
	// Options will go here
});