<?php
/*
Template Name: Gallery Template
*/
get_header();
?>
<?php
    while ( have_posts() ) :
    the_post();
?>

<section class="inner-banner" style="background-image: url('<?php echo get_post_meta(get_the_ID(),'wpcf-main-bg',true);?>');">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h2><?php the_title();?></h2>
					<ul class="custom-breadcam">
						<li><a href="#">Home</a></li>
						<li>Gallery</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="inner-about gallery custom-pad">
	<div class="container">
		<div class="row">
        <?php
                $args = array(
                'numberposts' => -1,
                'offset' => 0,
                'orderby' => 'post_date',
                'order' => 'ASC',
                'include' => '',
                'exclude' => '',
                'meta_key' => '',
                'meta_value' => '',
                'post_type' => 'gallery-image',
                'post_status' => 'draft, publish, future, pending, private',
                'suppress_filters' => true
                );
                $j = 1;
                $gallery = wp_get_recent_posts( $args, ARRAY_A );
                foreach ( $gallery as $gallery ) {
                $title = ($gallery['post_title']);
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery[ 'ID' ] ), 'single-post-thumbnail' );
            
            ?>
            
              <div class="col-md-4">
                  <div class="portion">
                      <h2><?php echo $title; ?></h2>
                      <img src="<?php echo $image[0]; ?>" alt="">
                      <a href="<?php echo $image[0]; ?>" data-fancybox="gallery" data-caption="<?php echo $title; ?>"><span class="fas fa-search"></span></a>
                  </div>
              </div>          


            <?php $j++;} ?>
		</div>
	</div>
</section>

<?php endwhile; ?>     
<?php
get_footer();
?>