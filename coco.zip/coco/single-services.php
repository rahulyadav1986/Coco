<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>

<section class="inner-banner" style="background-image: url('http://localhost/coco-cleaning/wp-content/uploads/2020/12/inner-banner.jpg');">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h2>Services</h2>
					<ul class="custom-breadcam">
						<li><a href="#">Home</a></li>
						<li>Services</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="inner-about custom-pad services">
    <div class="container">
        <?php
            // Start the Loop.
            while ( have_posts() ) :
                the_post();

                get_template_part( 'template-parts/content/content-single', 'single' );

            endwhile; // End the loop.
        ?>
    </div>
</section>
<?php
get_footer();