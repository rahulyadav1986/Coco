<?php
/*
Template Name: Welcome Template
*/
get_header();
?>
    <?php require_once('template-parts/banner.php')?>
    <?php require_once('template-parts/about.php')?>
    <?php require_once('template-parts/why_choose.php')?>
    <?php require_once('template-parts/pricing.php')?>
    <?php require_once('template-parts/contact.php')?>
<?php

get_footer();
?>