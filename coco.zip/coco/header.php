<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="search-box search-elem">
  <button class="close">x</button>
  <div class="inner row">
    <div class="col-md-12">
      <label class="placeholder" for="search-field">Search</label>
      <input type="text" id="search-field">
      <button class="submit" type="submit">Search</button>
    </div>
  </div>
</div>


<header class="custom-header">
  <div class="header-top">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <div class="dp-announcement">
		  <?php dynamic_sidebar('announcement') ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="dp-header-main">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-8 align-self-center">
          <div class="header-main-left">
            <nav class="navbar navbar-expand-lg"> <a class="navbar-brand dp-brand" href="#"> <?php dynamic_sidebar('logo') ?> </a>
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarSupportedContent" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
              </div>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
				<?php
					wp_nav_menu( array(
					'theme_location'    => 'header_menu',
					'depth'             => 2,
					'container'         => '',
					'container_class'   => '',
					'container_id'      => '',
					'menu_class'        => 'navbar-nav ml-auto',
					'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
					'walker'            => new wp_bootstrap_navwalker())
					);
				?>
              </div>
            </nav>
          </div>
        </div>
        <div class="col-lg-4 align-self-center">
          <div class="header-main-right">
			<div class="header-get-quote"> <a href="http://localhost/coco-cleaning/contact-us/">Get A Quote <span><i class="far fa-calendar-alt"></i></span></a> </div>			
            <ul class="top-social"> 
			  <li><a href="#" class="search-btn"><i class="fas fa-search"></i></a></li>             
			  <?php dynamic_sidebar('social') ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>


