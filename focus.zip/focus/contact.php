<?php
/*
Template Name: Contact Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <section class="tm-inner-banner" style="background-image: url(<?php echo get_post_meta(get_the_ID(),'wpcf-main-banner',true);?>);">
        <span class="tm-inner-banner-overlay"></span>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tm-inner-banner-text text-center">
                        <h1><?php the_title(); ?></h1>
                        <ul>
                            <li><a href="<?php echo get_home_url(); ?>">home</a></li>
                            <li><?php the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="tm-contact-top">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                   <div class="tm-contact-top-left">
                       <div class="tm-sec-inner-title">
                            <span><?php echo get_post_meta(get_the_ID(),'wpcf-contact-24hrs-heading',true);?></span>
                            <h2><?php the_title(); ?></h2>                            
                        </div>
                        <p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-contact-main-drescription',true);?></p>
                   </div> 
                </div>
                <div class="col-md-4">
                   <div class="tm-contact-top-right">
                    <h4><?php echo get_post_meta(get_the_ID(),'wpcf-question-heading',true);?></h4>
                    <p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-question-drescription',true);?></p>
                    <h6>Call Today:</h6>
                    <span><?php echo get_post_meta(get_the_ID(),'wpcf-main-phone-no',true);?></span>
                   </div>
               </div>
            </div>
        </div>
    </section>
    <section class="tm-contact-location">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="tm-contact-location-left">
                        <div class="tm-contact-location-left-title">
                            <h3><?php echo get_post_meta(get_the_ID(),'wpcf-office-location-heading',true);?></h3>
                        </div>
                        <?php echo get_post_meta(get_the_ID(),'wpcf-offices',true);?>
                        
                        
                    </div>
                </div>
                <div class="col-md-9">
                    <div>
                        <iframe src="<?php echo get_post_meta(get_the_ID(),'wpcf-office-map',true);?>" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="tm-contact-page-form">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="tm-contact-page-form-left">
                        <div class="tm-contact-location-left-title">
                            <h3><?php echo get_post_meta(get_the_ID(),'wpcf-office-timing-heading',true);?></h3>
                        </div>
                        <?php echo get_post_meta(get_the_ID(),'wpcf-office-timings-details',true);?>
                        
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="tm-contact-page-form-right">
                        <div class="tm-contact-location-left-title">
                            <h3><?php echo get_post_meta(get_the_ID(),'wpcf-help-heading',true);?></h3>
                            <p class="demo"><?php echo get_post_meta(get_the_ID(),'wpcf-help-drescription',true);?></p>
                        </div>
                        <div class="tm-contact-form">
                            <?php echo do_shortcode('[contact-form-7 id="5" title="Home Contact Form"]') ?> 
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    
    
  

<?php endwhile; ?>   
<?php

get_footer();
?>