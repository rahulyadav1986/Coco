<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>
<?php
    while ( have_posts() ) :
    the_post();
?>
<section class="tm-inner-banner" style="background-image: url(<?php echo get_post_meta(get_the_ID(),'wpcf-banner',true);?>);">
	<span class="tm-inner-banner-overlay"></span>
	<div class="container">
		<div class="tm-inner-banner-heading">
			<h1 class="tm-h1"><?php echo the_title(); ?></h1>         
			<div class="tm-btcm">
				<ul>
					<li><a href="<?php echo get_home_url(); ?>">Home</a></li>
					<li><?php echo the_title(); ?></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<section class="otherspage tm-custom-padding">
     <div class="container">
	 	<?php echo the_content(); ?>
     </div>
   </section>
<?php endwhile; ?>  
<?php
get_footer();
