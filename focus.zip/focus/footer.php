<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>

<footer class="tm-footer">
        <div class="tm-footer-top">
            <div class="container">
                <div class="col-md-12">
                    <div class="tm-footer-menu">
                        <div class="tm-footer-menu-left tm-footer-menu-list">
                        <?php
                            wp_nav_menu( array(
                            'theme_location'    => 'footer_menu1',
                            'container'  => '',
                            'depth'             => 2,
                            'items_wrap' => '<ul class="">%3$s</ul>' ,
                            'menu_class'        => '',
                            
                            ) );
                        ?>
                        </div>
                        <div class="tm-footer-menu-logo">
                            <a href="<?php echo get_home_url(); ?>"><?php dynamic_sidebar('f_logo') ?></a>
                        </div>
                        <div class="tm-footer-menu-right tm-footer-menu-list">
                        <?php
                            wp_nav_menu( array(
                            'theme_location'    => 'footer_menu2',
                            'container'  => '',
                            'depth'             => 2,
                            'items_wrap' => '<ul class="">%3$s</ul>' ,
                            'menu_class'        => '',
                            
                            ) );
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tm-footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tm-footer-copyright text-center">
                            <p class="demo"><?php dynamic_sidebar('copyright') ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-migrate-1.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.slicknav.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.fancybox.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/app.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl_thumb_script.js"></script>


<?php wp_footer(); ?>

</body>
</html>
