<?php
/*
Template Name: Welcome Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>
  
  <?php require_once('template-parts/banner.php') ?>
  <?php require_once('template-parts/services.php') ?>
  <?php require_once('template-parts/home_about.php') ?>
  <?php require_once('template-parts/article.php') ?>
  <?php require_once('template-parts/testimonials.php') ?>
  <?php require_once('template-parts/faq.php') ?>
  <?php require_once('template-parts/appointment.php') ?>
  

<?php endwhile; ?>   
<?php

get_footer();
?>