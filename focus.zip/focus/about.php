<?php
/*
Template Name: About Template
*/
get_header();
?>

<?php
    while ( have_posts() ) :
    the_post();
?>

<section class="tm-inner-banner" style="background-image: url(<?php echo get_post_meta(get_the_ID(),'wpcf-main-banner',true);?>);">
        <span class="tm-inner-banner-overlay"></span>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tm-inner-banner-text text-center">
                        <h1><?php the_title(); ?></h1>
                        <ul>
                            <li><a href="<?php echo get_home_url(); ?>">home</a></li>
                            <li><?php the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
  
  <section class="tm-about-us-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php the_content(); ?>   
                </div>
            </div>
        </div>
    </section>

    
    
  

<?php endwhile; ?>   
<?php

get_footer();
?>