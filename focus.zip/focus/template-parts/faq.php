<section class="tm-faq-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tm-sec-title text-center">
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-faq-title',true);?></h2>
                        <span><?php echo get_post_meta(get_the_ID(),'wpcf-faq-subtitle',true);?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php require_once('faq_accordion.php') ?>
                <?php require_once('faq_slider.php') ?>

            </div>
        </div>
    </section>