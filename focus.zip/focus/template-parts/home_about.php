<div class="about_details_back">
    <div class="container d-flex align-items-center">
        <div>
            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-home-about-main-avator',true);?>" class="person" alt="">
            <h1><?php echo get_post_meta(get_the_ID(),'wpcf-home-about-title',true);?></h1>
            <h3><?php echo get_post_meta(get_the_ID(),'wpcf-home-about-sub-title',true);?></h3>
            <p><?php echo get_post_meta(get_the_ID(),'wpcf-home-about-drescription',true);?></p>
            <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-home-about-signature',true);?>" alt="">
        </div>
        
    </div>
</div>
