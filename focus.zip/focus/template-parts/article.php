<div class="resources_back">
        <div class="container">
            <h2><?php echo get_post_meta(get_the_ID(),'wpcf-resources-heading',true);?></h2>
            <h3 class="sub_title"><?php echo get_post_meta(get_the_ID(),'wpcf-resources-sub-heading',true);?></h3>
            <div class="main_back owl-carousel" id="blog_carousel">
                <?php $query_args = array(
                        'post_type' => 'post',
                        'posts_per_page' => '6' ,
                        'order' => 'DESC'
                        );
                        $query = new WP_Query( $query_args ); ?>
                
                        <?php if ( $query->have_posts() ) : ?>
                            <?php while ( $query->have_posts() ) : $query->the_post(); get_template_part( 'template-parts/content/article-content' ); ?>
                            <?php endwhile; ?>
                        <?php endif; ?>

                    <?php wp_reset_postdata(); ?>                
            </div>
        </div>
    </div>