<div class="services_back">
        <div class="container">
            <h2>Highly Effective and Safe Male Enhancement<br>- Over 7,000 Satisfied Patients</h2>
            <div class="main_back">
                <div class="row">
                <?php $query_args = array(
                    'post_type' => 'services',
                    'posts_per_page' => '3' ,
                    'order' => 'DESC'
                    );
                    $query = new WP_Query( $query_args ); ?>
            
                    <?php if ( $query->have_posts() ) : ?>
                        <?php while ( $query->have_posts() ) : $query->the_post(); get_template_part( 'template-parts/content/service-content' ); ?>
                        <?php endwhile; ?>
                    <?php endif; ?>

                <?php wp_reset_postdata(); ?>   
                </div>
            </div>
        </div>
    </div>