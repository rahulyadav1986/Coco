<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>
<div class="portion">
    <?php twentynineteen_post_thumbnail(); ?>
    <div class="content_back">
        <div class="cal">
            <span class="fa fa-calendar"></span>
            <?php echo get_the_date( 'F j, Y' ) ?>
        </div>
        <h3><?php the_title(); ?></h3>
        <p><?php the_excerpt(); ?></p>
        <div class="custom_button">
            <a href="<?php the_permalink(); ?>">read more</a>
        </div>
    </div>
</div>