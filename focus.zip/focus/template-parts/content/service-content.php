<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>
<div class="col-md-6">
	<div class="portion">
		<img src="<?php echo get_post_meta(get_the_ID(),'wpcf-service-icon',true);?>" alt="" />
		<h3><?php the_title(); ?></h3>
		<p><?php the_excerpt(); ?></p>
		<div class="custom_button">
			<a href="<?php the_permalink(); ?>">learn more</a>
		</div>
	</div>
</div>