<div class="col-md-6">
    <div class="tm-faq-sec-main">
        <div class="accordion" id="faq">
        <?php
            $args = array(
            'numberposts' => -1,
            'offset' => 0,
            'orderby' => 'post_date',
            'order' => 'ASC',
            'include' => '',
            'exclude' => '',
            'meta_key' => '',
            'meta_value' => '',
            'post_type' => 'faq',
            'post_status' => 'draft, publish, future, pending, private',
            'suppress_filters' => true
            );
            $j = 1;
            $faq = wp_get_recent_posts( $args, ARRAY_A );
            foreach ( $faq as $faq ) {
            $title = ($faq['post_title']);
            $content = ($faq['post_content']);
            
        
            ?>
            <div class="card">
                <div class="card-header" id="faqhead<?php echo $j;?>">
                    <a href="#" class="btn btn-header-link" data-toggle="collapse" data-target="#faq<?php echo $j;?>"
                    aria-expanded="true" aria-controls="faq1"><?php echo $title ?></a>
                </div>
                <div id="faq<?php echo $j;?>" class="collapse <?php if($j==1) {?>show <?php }?>" aria-labelledby="faqhead<?php echo $j;?>" data-parent="#faq">
                    <div class="card-body">
                        <p class="demo"><?php echo $content ?></p>
                    </div>
                </div>
            </div> 
            <?php $j++;} ?>                       
        </div>
    </div>
</div>