<section class="tm-contact-us">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tm-sec-title text-center">
                        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-appointment-title',true);?></h2>
                        <span><?php echo get_post_meta(get_the_ID(),'wpcf-appointment-subtitle',true);?></span>
                    </div>
                </div>
            </div>
            <div class="row">
          <div class="col-md-8 offset-lg-2">
            <div class="tm-contact-form">
               <?php echo do_shortcode('[contact-form-7 id="5" title="Appointment Form"]') ?>
             </div>
          </div>
        </div>
        </div>
    </section>

  