<div class="services_back">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <h2><?php echo get_post_meta(get_the_ID(),'wpcf-service-title',true);?></h2>
                <h4><?php echo get_post_meta(get_the_ID(),'wpcf-service-subtitle',true);?></h4>
                <p><?php echo get_post_meta(get_the_ID(),'wpcf-service-drescription',true);?></p>
                    <div class="custom_button">
                        <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-service-button-url',true);?>"><?php echo get_post_meta(get_the_ID(),'wpcf-service-button-text',true);?></a>
                    </div>
            </div>
            <div class="col-lg-7 item">
                <div class="row">                        
                    <?php $query_args = array(
                    'post_type' => 'services',
                    'posts_per_page' => '4' ,
                    'order' => 'DESC'
                    );
                    $query = new WP_Query( $query_args ); ?>
            
                    <?php if ( $query->have_posts() ) : ?>
                        <?php while ( $query->have_posts() ) : $query->the_post(); get_template_part( 'template-parts/content/service-content' ); ?>
                        <?php endwhile; ?>
                    <?php endif; ?>

                    <?php wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </div>
</div>