<div class="col-md-6">
                    <div class="tm-faq-sec-owl-carousel">
                        <div class="outer">
                            <div id="big" class="owl-carousel">
                            <?php
                                $args = array(
                                'numberposts' => -1,
                                'offset' => 0,
                                'orderby' => 'post_date',
                                'order' => 'ASC',
                                'include' => '',
                                'exclude' => '',
                                'meta_key' => '',
                                'meta_value' => '',
                                'post_type' => 'f_slider',
                                'post_status' => 'draft, publish, future, pending, private',
                                'suppress_filters' => true
                                );
                                $j = 1;
                                $f_slider = wp_get_recent_posts( $args, ARRAY_A );
                                foreach ( $f_slider as $f_slider ) {                                
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $f_slider[ 'ID' ] ), 'single-post-thumbnail' );
                            
                            ?>
                              <div class="item">
                                <div class="tm-faq-sec-owl-carousel-img">
                                    <img src="<?php echo $image[0]; ?>" alt="" class="img-fluid">
                                </div>
                              </div>
                            <?php $j++;} ?> 
                            </div>
                            <div id="thumbs" class="owl-carousel owl-theme">
                            <?php
                                $args = array(
                                'numberposts' => -1,
                                'offset' => 0,
                                'orderby' => 'post_date',
                                'order' => 'ASC',
                                'include' => '',
                                'exclude' => '',
                                'meta_key' => '',
                                'meta_value' => '',
                                'post_type' => 'f_slider',
                                'post_status' => 'draft, publish, future, pending, private',
                                'suppress_filters' => true
                                );
                                $j = 1;
                                $f_slider = wp_get_recent_posts( $args, ARRAY_A );
                                foreach ( $f_slider as $f_slider ) {                                
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $f_slider[ 'ID' ] ), 'single-post-thumbnail' );
                            
                            ?>
                              <div class="item">
                                <div class="tm-faq-sec-owl-carousel-img-thumbs">
                                    <img src="<?php echo $image[0]; ?>" alt="" class="img-fluid">   
                                </div>
                              </div>
                              <?php $j++;} ?>
                            </div>
                        </div>
                    </div>
                </div>