<section class="tm-testimonials" style="background-image: url(<?php echo get_post_meta(get_the_ID(),'wpcf-testimonial-bg',true);?>);">

    <span class="tm-testimonials-overlay"></span>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div id="testimonials-carousel" class="owl-carousel">
                    <?php
					  $args = array(
                        'numberposts' => -1,
                        'offset' => 0,
                        'orderby' => 'post_date',
                        'order' => 'ASC',
                        'include' => '',
                        'exclude' => '',
                        'meta_key' => '',
                        'meta_value' => '',
                        'post_type' => 'testimonial',
                        'post_status' => 'draft, publish, future, pending, private',
                        'suppress_filters' => true
                        );
                        $j = 1;
                        $testimonial = wp_get_recent_posts( $args, ARRAY_A );
                        foreach ( $testimonial as $testimonial ) {
                        $title = ($testimonial['post_title']);
                        $content = ($testimonial['post_content']);
                        
				  
				     ?>
                    <div class="item">
                        <div class="tm-testimonials-panel text-center">
                            <p class="demo"><?php echo $content; ?></p>
                            <span><?php echo $title; ?></span>
                        </div>
                    </div>
                    <?php $j++;} ?>
                </div>
            </div>
        </div>
    </div>
</section>