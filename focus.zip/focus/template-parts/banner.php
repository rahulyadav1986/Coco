<div class="hero d-flex align-items-center justify-content-center">
    <img src="<?php echo get_post_meta(get_the_ID(),'wpcf-main-banner',true);?>" alt="">
    <div class="container">
        <h2><?php echo get_post_meta(get_the_ID(),'wpcf-banner-title',true);?></h2>
        <div class="custom_button">
            <a href="<?php echo get_post_meta(get_the_ID(),'wpcf-banner-button-url',true);?>"><?php echo get_post_meta(get_the_ID(),'wpcf-banner-button-text',true);?></a>
        </div>
    </div>
</div>

   